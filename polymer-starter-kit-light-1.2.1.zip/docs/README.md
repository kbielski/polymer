# Recipes

* [Add ES2015 (formally ES6) support using Babel](add-es2015-support-babel.md)
* [Polymer Performance Recipe](polymer-perf.md)
* [Use PSK with Chrome Dev Editor](chrome-dev-editor.md)
* [Deploy to Github Pages](deploy-to-github-pages.md)
* [Deploy to Firebase using Pretty URLs](deploy-to-firebase-pretty-urls.md)
* [Use PSK for Mobile Chrome Apps](mobile-chrome-apps.md)
